<?php 
    $db = mysqli_connect('localhost', 'root', '', '05122018_3project');
    mysqli_set_charset($db, 'utf8');