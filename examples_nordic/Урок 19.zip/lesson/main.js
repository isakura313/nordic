// let day1 = 'Понедельник';
// let day2 = 'Вторник';
// let day3 = 'Среда';

// console.log(day1);
// console.log(day2);
// console.log(day3);

let days = ['Понедельник', 'Вторник', 'Среда', 'Четверг', 
                            'Пятница', 'Суббота', 'Воскр'];

console.log( days[0] );
console.log( days[2] );
console.log( days[6] );

// let userDay = prompt('Какой день недели ты хочешь увидеть?');
// alert( days[userDay] );
console.log(days);
days[0] = 'Воскр';
console.log(days);

days.push('Понескрес.');
console.log(days);

console.log( days.length );
console.log( days[days.length - 1] );

let salary = [40000, 42000, 142000, 57699, 34000, 23000];

console.log( ( salary[0] + salary[salary.length - 1] )/2 )
console.log( salary[salary.length - 1],  salary[salary.length - 2], salary[salary.length - 3]);

// console.log( salary[0] );
// console.log( salary[0] + salary[1] );
// console.log( salary[0] + salary[1] + salary[2] );
// console.log( salary[0] + salary[1] + salary[2] + salary[3] );
// console.log( salary[0] + salary[1] + salary[2] + salary[3] + salary[4] );
// console.log( salary[0] + salary[1] + salary[2] + salary[3] + salary[4] + salary[5] );

// let sum = 0;

// sum = salary[0];
// console.log( sum );

// sum = sum + salary[1];
// console.log( sum );

// sum = sum + salary[2];
// console.log( sum );

// sum = sum + salary[3];
// console.log( sum );

// sum = sum + salary[4];
// console.log( sum );

// sum = sum + salary[5];
// console.log( sum );
//salary = [40000, 42000, 142000, 57699, 34000, 23000];
let sum = 0;
salary.forEach(function(element, index){
    sum = sum + salary[index];
    //sum = sum + element;
    console.log(sum);
});

let min = salary[0];
salary.forEach(function(element, index){
    if( min > salary[index] ){
        min = salary[index];
    }
});
console.log(min);

let max = salary[0];
salary.forEach(function(element, index){
    if( max < salary[index] ){
        max = salary[index];    
    }
});

let max_other = salary[0];
let min_other = salary[0];
let min_index = 0;
let max_index = 0;
salary.forEach(function(element, index){
    if( max_other < salary[index] ){
        max_other = salary[index];
        max_index = index;
    }

    if( min_other > salary[index] ){
        min_other = salary[index];
        min_index = index;
    }
});
console.log( (max_other + min_other) / 2 )
console.log('До:', salary);
let a = salary[min_index];
salary[min_index] = salary[max_index];
salary[max_index] = a;
console.log('После:', salary);