let app = new Vue({
    el: '.app',
    data: {
        title: 'Привет, мир'
    }
});

let timerApp = new Vue({
    el: '.timer',
    data:{
        seconds: 10,
        adShow: true,
        clicks: 0
    }
});

setInterval(()=>{
    if( timerApp.seconds == 0 ){
        if( timerApp.clicks < 10 ){
            alert('Вы проиграли');
        }else{
            alert('Вы выиграли');
        }

        timerApp.adShow = false;
    }else{
        timerApp.seconds--;
    }
}, 1000);

let btn = document.querySelector('button');
btn.addEventListener('click', function(){
    timerApp.clicks++;
});