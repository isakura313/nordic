<?php 
    $db = mysqli_connect('localhost', 'root', '', '20180512_33');
    mysqli_set_charset($db, 'utf8');
?>