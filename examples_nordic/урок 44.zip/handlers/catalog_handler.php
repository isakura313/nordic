<?php 
    require_once($_SERVER['DOCUMENT_ROOT'].'/config/configuration.php');
    require_once($_SERVER['DOCUMENT_ROOT'].'/config/functions.php');
    
    $page = (int) $_GET['page'];
    
    $sql_count_rows = "SELECT COUNT(id) as len FROM products";
    $result_count_rows = mysqli_query($db, $sql_count_rows);
    $result_count_rows_arr = mysqli_fetch_assoc($result_count_rows);
    $count_rows = $result_count_rows_arr['len'];

    $count_products_on_page = 5;

    // ceil() - округление в большую сторону
    $count_page = ceil($count_rows / $count_products_on_page);

    $response = [
        'products'=>[],
        'pagination'=>[
            'countPage'=> $count_page,
            'nowPage'=>$page
        ]
    ];

    $from_row = $count_products_on_page * ($page - 1);
    /*
        1 - 0
        2 - 5
        3 - 10
    */
    $sql_products = "SELECT * FROM products limit {$from_row}, {$count_products_on_page}";
    $result_products = mysqli_query($db, $sql_products);

    while( $row = mysqli_fetch_assoc($result_products) ){
        // d($row);
        $response['products'][] = $row;
    }


    echo json_encode( $response );