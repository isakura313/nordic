<?php 
$pageConfig = [
    'title'=>'Корзина',
    'cssFiles'=>[
        '/css/style.css',
        '/css/basket.css'
    ],
    'jsFiles'=>[
        '/js/script.js'
    ],
];
include($_SERVER['DOCUMENT_ROOT'].'/parts/header.php');
?>

<?php 
    include($_SERVER['DOCUMENT_ROOT'].'/parts/footer.php');
?>
