-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Мар 01 2019 г., 10:03
-- Версия сервера: 10.1.37-MariaDB
-- Версия PHP: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `20180512_33`
--
CREATE DATABASE IF NOT EXISTS `20180512_33` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `20180512_33`;

-- --------------------------------------------------------

--
-- Структура таблицы `cards`
--

CREATE TABLE IF NOT EXISTS `cards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `content` text NOT NULL,
  `img_src` varchar(255) NOT NULL,
  `priority` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `attention` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `cards`
--

INSERT INTO `cards` (`id`, `name`, `content`, `img_src`, `priority`, `active`, `attention`) VALUES
(1, 'Путешествия по России', 'Самые интересные путешествия', '/icon/moscow.png', 10, 1, 0),
(2, 'Путешествия по Африке', 'В общем, какое бы время вы ни выбрали, Роза Хутор удивит и подарит желание говорить о России с восторгом!', '/icon/pyramids.png', 20, 1, 0),
(3, 'Путешествия по Австралии', 'Самые интересные путешествия', '/icon/kangaroo.png', 30, 1, 1),
(4, 'Путешествия по Америке', 'Самые интересные путешествия', '/icon/north-america.png', 40, 1, 0),
(5, 'Путешествия по Южной Америке', 'Самые интересные путешествия', '/icon/south-america.png', 50, 1, 0),
(6, 'Путешествия по Англии', 'Самые интересные путешествия', '/icon/big-ben.png', 60, 1, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `menu`
--

CREATE TABLE IF NOT EXISTS `menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `href` varchar(255) NOT NULL,
  `priority` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `menu`
--

INSERT INTO `menu` (`id`, `name`, `href`, `priority`, `active`) VALUES
(1, 'Главная', '/', 100, 1),
(2, 'О нас', '/about.php', 110, 0),
(3, 'Оставить вопрос', '#', 80, 1),
(4, 'Контакты', '#', 70, 1);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
