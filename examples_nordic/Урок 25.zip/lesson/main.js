let age = 28;

console.log(age);
//Прошел год
age = 29;
console.log(age);

let salaryNadia = 100000;
let salaryVasya = 100000;
let yearSalary = (salaryNadia + salaryVasya)*12

let carPrice = 3200000;
let ipoteka = 60000;
let food = 45000;

let depositMoney = salaryNadia + salaryVasya - ipoteka - food;
let monthToDream = carPrice/depositMoney;
console.log(monthToDream);

let nameVasya = 'Вася';
let year;
console.log(year * 100);
console.log(11 % 2);

console.log( nameVasya + ' зарабатывает ' + salaryVasya + salaryNadia + ' руб' );

console.log( salaryVasya + salaryNadia + ' ' + nameVasya + ' зарабатывает ');

console.log( `${nameVasya} зарабатывает ${salaryVasya} руб.` );

let a = 10;
let b = 20;
let c;

c = a;
a = b;
b = c;

let t = -40;

if( t < -16 ){
    console.log('Надень шапку-ушанку');
}else if( t < 0 ){
    console.log('Надень шапку');  
}else{
    console.log('Гуляй в чем хочешь')
}

if( a > b ){
    console.log('a > b');
}else if( a < b ){
    console.log( 'a < b' );
}else{
    console.log( 'a = b' );
}

if( monthToDream > 36 ){
    console.log('Надя против');
    let newCar = depositMoney * 36;
    console.log(`Найди машину за ${newCar}`);
}else{
    console.log('Надя за');
    $('body').css('background', 'url(car.jpeg)');
}

let howAreYou = prompt('Как дела?');
console.log(howAreYou);