<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Отправка формы</title>
</head>
<body>
    <h1>Оставьте вашу заявку</h1>
    <form action="/form-ajax/handler.php" method="POST">
        <input type="text" name="firstname" placeholder="Ваше имя">
        <input type="text" name="lastname" placeholder="Ваша фамилия">
        <input type="text" name="age" placeholder="Сколько лет?">
        <button type="submit">Отправить</button>
    </form>

    <script src="form.js"></script>
    <!-- http://localhost/form-ajax/handler.php?firstname=Slava&lastname=Zhukov -->
</body>
</html>