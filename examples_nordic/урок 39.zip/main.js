document.querySelector('button').addEventListener('click', function(){
    this.disabled = true;

    let input = document.querySelector('input');
    console.log(input.value);

    let xhr = new XMLHttpRequest();
    xhr.open('GET', `/handler.php?word=${input.value}`);
    xhr.send();

    let that = this;
    xhr.addEventListener('load', function(){
        
        let resultEl = document.querySelector('.result');
        resultEl.innerHTML = xhr.responseText;

        that.disabled = false;
    });
});