// alert('Привет, мир!');
// alert('Привет, мир 2!');
// alert('Привет, мир 3!');

$('body').css('background-color', 'red');
$('.header').css('background-color', 'green');

$('.main-picture-content h1').hide();
$('.main-picture-content h1').fadeIn(5000);
$('.main-picture-content h1').fadeOut(5000);

$('.form-request .button').click(function(){
    //alert('Событие работает');
    $(".form-request-popup").css('display', 'flex').hide().fadeIn(1000);
});

$('.main-picture-content .button').click(function(){
    $(".form-request-popup").css('display', 'flex').hide().fadeIn(1000);
});

$('.form-request-popup-close').click(function(){
    $(".form-request-popup").fadeOut(1000);
    
});

//Вопрос-ответ

$('.questions-box-item').click(function(){
   // $(this) - это тот элемент на который я кликнул
   // find() - позволяет мне искать элементы внутри элемента

   $(this).find('.questions-box-item-a').slideToggle(500);

    // $('.questions-box-item-a').slideToggle(500);
});