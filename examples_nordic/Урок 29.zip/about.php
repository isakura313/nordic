<?php 
    $title = "О нас";
    include('parts/header.php');
?>
<div class="article">
    <h1>Страница о нас</h1>
    <p>Мы 2 миллиона лет на рынке</p>
</div>
<?php 
    include('parts/footer.php');
?>