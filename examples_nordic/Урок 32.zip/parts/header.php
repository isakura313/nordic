<?php 
    require_once($_SERVER['DOCUMENT_ROOT'].'/parts/functions.php');
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title><?php echo "Путешествия || $title"; ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no
    ">
    <link href="https://fonts.googleapis.com/css?family=PT+Sans:400,700" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="wrapper">
        <div class="header">
            <a href="#" id='logo' class="nav logo"></a>
            <div class="nav-box">
                <a href="/" class="nav">Главная</a>
                <a href="/about.php" class="nav nav-about-us">О нас</a>
                <a href="#" class="nav nav-faq">Оставить вопрос</a>
                <a href="#" class="nav">Контакты</a>
            </div>
            <div class="burger">
                <div></div>
            </div>
        </div>