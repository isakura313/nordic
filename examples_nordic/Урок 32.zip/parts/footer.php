<div class="arrow-up"></div>
    
    <!-- <script>
        alert('Привет, мир!');
        alert('Привет, мир 2!');
        alert('Привет, мир 3!');
    </script> -->
    <script src="jquery-3.3.1.min.js"></script>
    <script src="main.js"></script>
</body>
</html>