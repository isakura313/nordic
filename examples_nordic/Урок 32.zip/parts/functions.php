<?php 

    // Пользовательские функции

    // debug
    function d($arr) {
        echo '<pre>';
        print_r($arr);
        echo '</pre>';
    }

?>