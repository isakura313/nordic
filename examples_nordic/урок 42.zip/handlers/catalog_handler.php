<?php 
    require_once($_SERVER['DOCUMENT_ROOT'].'/config/configuration.php');
    require_once($_SERVER['DOCUMENT_ROOT'].'/config/functions.php');

    $sql_products = "SELECT * FROM products";
    $result_products = mysqli_query($db, $sql_products);

    while( $row = mysqli_fetch_assoc($result_products) ){
        d($row);
    }
