// alert('Привет, мир!');
// alert('Привет, мир 2!');
// alert('Привет, мир 3!');

$('body').css('background-color', 'red');
$('.header').css('background-color', 'green');

$('.main-picture-content h1').hide();
$('.main-picture-content h1').fadeIn(5000);
$('.main-picture-content h1').fadeOut(5000);