let slider = $('.slider');
let sliderLenta = slider.find('.slider-lenta');
let sliderItems = slider.find('.slider-lenta-item');

//sliderItems.length 
let nowShowIndex = 0;
//eq() - jquery метод, позволяющий брать n-ый элемент из набора

slider.find('.slider-arrow-left').click(function(){
    if( nowShowIndex <= 0 ){
        nowShowIndex = sliderItems.length - 1;
    }else{
        nowShowIndex = nowShowIndex -1;       
    }

    sliderLenta.animate({
        left: -100 * nowShowIndex + "%"
    }, 500);

    // if( nowShowIndex <= 0 ){
    //     sliderItems.eq(nowShowIndex).fadeOut();
    //     nowShowIndex = sliderItems.length - 1;
    //     sliderItems.eq(nowShowIndex).css('display', 'flex');    
    // }else{
    //     sliderItems.eq(nowShowIndex).fadeOut();
    //     sliderItems.eq(nowShowIndex - 1).css('display', 'flex');
    //     nowShowIndex = nowShowIndex - 1;
    // }

        // sliderItems.eq(nowShowIndex).hide();
        // sliderItems.eq(nowShowIndex - 1).css('display', 'flex');
        // nowShowIndex = nowShowIndex - 1;

        // if( nowShowIndex < 0 ){
        //     nowShowIndex = sliderItems.length-1;
        //     sliderItems.eq(nowShowIndex).css('display','flex');
        // }
});

slider.find('.slider-arrow-right').click(function(){
    if( nowShowIndex >= sliderItems.length - 1 ){
        nowShowIndex = 0;
    }else{
        nowShowIndex = nowShowIndex + 1;
        /* 
        0:  0%;
        1:  -100%
        2:  -200%
        
       */
    }

    sliderLenta.animate({
        left: -100 * nowShowIndex + "%"
    }, 500);

    // if( nowShowIndex >= sliderItems.length - 1){
    //     sliderItems.eq(nowShowIndex).fadeOut(500, function(){
    //         nowShowIndex = 0;
    //         sliderItems.eq(nowShowIndex).css('display', 'flex');
    //     });

    //     // nowShowIndex = 0;
    //     // sliderItems.eq(nowShowIndex).css('display', 'flex');
    //     //Ветка, когда мы в последнем слайде           
    // }else{
    //     sliderItems.eq(nowShowIndex).fadeOut();
    //     sliderItems.eq(nowShowIndex + 1).css('display', 'flex');
    //     nowShowIndex = nowShowIndex + 1;
    // }
});

//setInterval - функция управления временем, таймер

// setInterval(function(){
//     slider.find('.slider-arrow-right').click();   
// }, 1000);