$(document).ready(function(){
    let box = $('.box');
    let target = box.find('.target');

    $('.box-orange').click(function(){
        target.parents('.box').css('background-color', 'orange');    
    });

    $('.wrapper-gray').click(function(){
        target.parents('.wrapper').css('background-color', 'gray');
    });

    $('.manager-red').click(function(){
        target.parents('.wrapper').find('.manager').css('background-color', 'red');
    });

    $('.next-purple').click(function(){
        target.next().css('background-color', 'purple');
    });

    // box.find('.box-item').click(function(e){
    //     e.stopPropagation();
    //     $(this).remove();
    // });

    box.click(function(){
        $(this).empty();
    });

    $('.box').on('click', '.box-item', function(e){
        e.stopPropagation();
        $(this).remove();
    });

    function restart(direction){
        box.empty();

        for( let i = 1; i <= 5; i++ ){
            let boxItem = $("<div></div>");

            if( i == 3 ){
                boxItem.addClass('target');
                target = boxItem;
            }
            boxItem.addClass('box-item');
            boxItem.html(i);

            // boxItem.click(function(e){
            //     e.stopPropagation();
            //     $(this).remove();
            // });
            
            if( direction == 'simple' ){
                box.append( boxItem );
            }else if( direction == 'reverse' ){
                box.prepend( boxItem );    
            }else if( direction == 'alternation' ){
                if( i % 2 != 0 ){
                    box.append( boxItem );    
                }else{
                    boxItem.remove();   
                }
            }
            
        }
    }
    //1 3 5
    $('.restart').click(function(){
        restart('simple');
    });

    $('.alternation').click(function(){
        restart('alternation');    
    });

    $(".reverse-restart").click(function(){
        restart('reverse');
        // box.empty();
        // for(let i = 5; i >= 1; i--){
        //     let boxItem = $("<div></div>");

        //     if( i == 3 ){
        //         boxItem.addClass('target');
        //         target = boxItem;
        //     }
        //     boxItem.addClass('box-item');
        //     boxItem.html(i);

        //     boxItem.click(function(e){
        //         e.stopPropagation();
        //         $(this).remove();
        //     });
            
        //     box.append( boxItem );
        // }
    });

    $(".create-six").click(function(){
        let boxItem = $("<a></a>");
        boxItem.attr('href',  'https://inordic.ru');
        boxItem.addClass('box-item');
        boxItem.html(6);
        box.append(boxItem);

        boxItem.click(function(e){
            e.stopPropagation();
            $(this).remove();
        });
    });
});
