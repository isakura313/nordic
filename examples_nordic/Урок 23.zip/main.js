let box = $('.box');
let target = box.find('.target');

$('.box-orange').click(function(){
    target.parents('.box').css('background-color', 'orange');    
});

$('.wrapper-gray').click(function(){
    target.parents('.wrapper').css('background-color', 'gray');
});

$('.manager-red').click(function(){
    target.parents('.wrapper').find('.manager').css('background-color', 'red');
});

$('.next-purple').click(function(){
    target.next().css('background-color', 'purple');
});

box.find('.box-item').click(function(e){
    e.stopPropagation();
    $(this).remove();
});

box.click(function(){
    $(this).empty();
});

$('.restart').click(function(){
    box.empty();

    for( let i = 1; i <= 5; i++ ){
        let boxItem = $("<div></div>");

        if( i == 3 ){
            boxItem.addClass('target');
        }
        boxItem.addClass('box-item');
        boxItem.html(i);
    
        box.append( boxItem );
    }
});