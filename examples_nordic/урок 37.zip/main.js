let petya = {
    name: 'Петр Иванов',
    age: 56,
    job: 'Мукомол',
    img_src: 'petr.jpg',
    messageList: ['Привет', 'Где тут аптека?', 'Зачем', 'Ты что совсем?', 'Ой все'],
    messageEl: document.querySelector('.chat-message'),
    sayHello(){
        alert(`Привет, меня зовут ${this.name}, мне ${this.age}`);
    },
    showJob(){
        alert(`Я ${this.job}`);
    },
    render(el){
        let div = document.createElement('div');
        div.classList.add('chat-hero-content');
        div.innerHTML = `
            <h2>${this.name}</h2>
            <img src='${this.img_src}'>
            <p>${this.age} лет, ${this.job}</p>
        `;

        el.appendChild(div);
    },
    message(){
        if( this.messageList.length == 0 ) return;

        let p = document.createElement('p');
        p.innerHTML = `<span class='hero-message-1'>${this.messageList.shift()}</span>`;
        p.style.textAlign = 'left';
        p.style.color = 'green';

        this.messageEl.appendChild(p);
    }
};

let vasya = {
    name: 'Василий Уткин',
    age: 56,
    job: 'Коментатор',
    img_src: 'utkin.jpg',
    messageList: ['Привет', 'По чем семечки', 'Дай свой номер', 'И чо?', 'ШТА?'],
    messageEl: document.querySelector('.chat-message'),
    sayHello(){
        alert(`Привет, меня зовут ${this.name}, мне ${this.age}`);
    },
    showJob(){
        alert(`Я ${this.job}`);
    },
    render(el){
        let div = document.createElement('div');
        div.classList.add('chat-hero-content');
        div.innerHTML = `
            <h2>${this.name}</h2>
            <img src='${this.img_src}'>
            <p>${this.age} лет, ${this.job}</p>
        `;

        el.appendChild(div);
    },
    message(){
        if( this.messageList.length == 0 ) return;

        let p = document.createElement('p');
        p.innerHTML = `<span class='hero-message-2'>${this.messageList.shift()}</span>`;
        p.style.textAlign = 'right';
        p.style.color = 'red';

        this.messageEl.appendChild(p);
    }
};

// petya.sayHello();
// petya.showJob();
petya.render( document.querySelector('.hero-1') );
vasya.render( document.querySelector('.hero-2') );


setInterval(()=>{
    vasya.message();
    petya.message();
}, 2000);


// alert(petya.name);
// alert(petya.age);