let ar = [0, 1, 2, 10, 45];

ar.forEach(function(element, index){
    console.log(element, index);
});

let my_ar = [];
for(let i = 0; i <= 9; i++){
    // if( (i % 2) == 0 ){
    //     my_ar.push(1);
    // }else{
    //     my_ar.push(0);
    // }
    if(  my_ar.length == 0 ) {
        my_ar.push(0);
    }else{
        if( my_ar[i-1] == 0 ){
            my_ar.push(1);  
        }else{
            my_ar.push(0);     
        }
    }    
}

console.log( my_ar );