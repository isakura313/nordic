<div class="arrow-up"></div>
<div class="snowflake"></div>
<?php 
    $sql = "SELECT * FROM menu ORDER BY priority DESC";

    $result = mysqli_query($db, $sql);

    // d( mysqli_fetch_assoc($result) );
    // d( mysqli_fetch_assoc($result) );
    // d( mysqli_fetch_assoc($result) );
    // d( mysqli_fetch_assoc($result) );

    while( $row = mysqli_fetch_assoc($result) ){
        echo "<a href='{$row['href']}' class='nav'>{$row['name']}</a>";    
    }
?>
    
    <!-- <script>
        alert('Привет, мир!');
        alert('Привет, мир 2!');
        alert('Привет, мир 3!');
    </script> -->
    <script src="jquery-3.3.1.min.js"></script>
    <script src="main.js"></script>
    <script src="vanilla.js"></script>
</body>
</html>