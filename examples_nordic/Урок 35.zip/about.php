<?php 
    $title = "О нас";
    include( $_SERVER['DOCUMENT_ROOT'] . '/parts/functions.php');
    include( $_SERVER['DOCUMENT_ROOT'] . '/parts/header.php');
    
    if ( $_SERVER['SERVER_ADDR'] != '127.0.0.1') {
        echo 'У вас нет прав на просмотр. Идите вон!';
        die();
    }

?>
<div class="article">
    <h1>Страница о нас</h1>
    <p>Мы 2 миллиона лет на рынке</p>
    <?php 
    
        // array();     // старый вариант
        $auto = [
            'peugeot' => [
                '306' => [
                    'цвет' => 'желтый',
                    'лошадиные силы' => 150,
                    'количество мест' => 5
                ],
                '3008' => [
                    'цвет' => 'синий',
                    'лошадиные силы' => 210,
                    'количество мест' => 6,
                    'количество колес' => 4
                ]
            ], 
            'лада' => [], 
            'BMW' => [], 
            'Audi' => []
        ];     // современный вариант 5.5


        foreach ( $auto['peugeot'][3008] as $key => $value ) {
 
            if ( $key == 'цвет' || $key= 'количество колес') {
                echo "<div>$key</div>";
            } 

            

            // foreach( $value as $option => $opt_value ) {
            //     echo "<div style='font-style: italic; margin-left: 20px;'>$option : $opt_value</div>";
            // }

        }

        d($_GET);

        // empty() - проверяет массив на пустоту;
        if ( !empty($_GET) ) {
            echo 'А ничего не отправлено. Идие вон!';
        } else {
            echo "Привет, {$_GET['fio']} <br>";
            echo 'Мы отправим тебе письмо на почту: ' . $_GET['email'];
        }
        
     
    ?>

</div>
<?php 
    include($_SERVER['DOCUMENT_ROOT'] . '/parts/footer.php');
?>