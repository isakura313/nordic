document.body.style.backgroundColor = 'green';

setInterval(function(){
    // document.body.style.backgroundColor = `rgb(${255 * Math.random()}, ${255*Math.random()}, ${255*Math.random()})`;    
}, 100);

let mainH2 = document.getElementById('main_h2');
mainH2.style.color = 'orange';
mainH2.innerHTML = 'Привет, мир!';

let cardsBlock = document.querySelector('.cards-block');
cardsBlock.style.opacity = '0.8';

let cardsBlockItems = cardsBlock.querySelectorAll('.cards-block-item');
console.log(cardsBlockItems);
// cardsBlockItems.style.backgroundColor = 'red';

// let status = true;
setInterval(function(){
    cardsBlock.classList.toggle('active');
    cardsBlockItems.forEach(function(item, index){
        // if( status ){
        //     if( index % 2 == 0){
        //         item.style.backgroundColor = 'red';
        //     }else{
        //         item.style.backgroundColor = 'white';    
        //     }
        // }else{
        //     if( index % 2 == 0){
        //         item.style.backgroundColor = 'white';
        //     }else{
        //         item.style.backgroundColor = 'green';    
        //     }
        // }

        if( index % 2 == 0){
            item.style.backgroundColor = (cardsBlock.classList.contains('active')) ? 'red' : 'white';
        }else{
            item.style.backgroundColor = (cardsBlock.classList.contains('active')) ? 'white' : 'green';    
        }
    });

    status = !status;
    console.log(status);
}, 2000);


let limitSnow = 100;

setInterval(function(){
    limitSnow--;
    if( limitSnow > 0 ){
        let snowFlake = document.createElement('div');
        snowFlake.style.left = `${Math.random() * 100}%`;
        snowFlake.style.animationDuration = `${10-Math.random()*5}s`;
        snowFlake.classList.add('snowflake');
        document.body.appendChild(snowFlake);

        snowFlake.addEventListener('click', function(){
            this.style.display = 'none';
        });
    }
}, 500)