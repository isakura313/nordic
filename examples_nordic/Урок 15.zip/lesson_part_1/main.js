let login = 'admin';
let password = 'adminadmin';

let user_login = prompt('Введите логин');
let user_pass = prompt('Введите пароль');

// if( login == user_login ){
//     if( password == user_pass ){
//         alert('Земля круглая');
//     }else{
//         alert('Мы вас не знаем');    
//     }
// }else{
//     alert('Мы вас не знаем');
// }

if( login == user_login && password == user_pass ){
    alert('Земля круглая');
}else{
    alert('Мы вас не знаем');    
}

let num = 1;
num = 1;

// if( num == 0 ){
//     alert( `${num} рублей` );
// }else if(num == 1){
//     alert( `${num} рубль` );
// }else if( num >=2 && num <= 4 ){
//     alert( `${num} рубля` );
// }else if( num >= 5 && num <= 20 ){
//     alert( `${num} рублей` );
// }

let mod = num % 100;
let postfix = ``;
if( mod >= 11 && mod <= 19 ){
    postfix = 'рублей';
}else{
    mod = mod % 10;
    if( mod == 0 || ( mod >=5 && mod <= 9 ) ){
        postfix = 'рублей';   
    }else if( mod >=2 && mod <=4 ){
        postfix = 'рубля';
    }else{
        postfix = 'рубль';    
    }
}
alert(`${num} ${postfix}`);
/*
    0 рублей
    1 рубль
    2 рубля
    3 рубля
    4 рубля
    5 рублей
    6 рублей
    10 рублей
    11-19 рублей
    20 рублей
    21 - рубль
    30 - рублей
    1012001203100 рублей
*/