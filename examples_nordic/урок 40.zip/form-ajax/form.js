let form = document.querySelector('form');

form.addEventListener('submit', function(e){
    e.preventDefault();

    let xhr = new XMLHttpRequest();

    let firstNameInput = this.querySelector('[name=firstname]');
    let lastNameInput = this.querySelector('[name=lastname]');
    let ageInput = this.querySelector('[name=age]');

    /*
        this.action = /form-ajax/handler.php
        /form-ajax/handler.php?firstname=Test&lastname=Test
    
    */
    // Случая для GET-отправки
    // xhr.open(this.method, 
    //     `${this.action}?firstname=${firstNameInput.value}&lastname=${lastNameInput.value}&age=${ageInput.value}`);
    // xhr.send();

    xhr.open(this.method, this.action);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.send(`firstname=${firstNameInput.value}&lastname=${lastNameInput.value}&age=${ageInput.value}`);

    xhr.addEventListener('load', function(){
        alert(xhr.responseText);
    });
});