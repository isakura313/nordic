<?php 
    // echo "<pre>";
    // print_r( $_GET );
    // echo "</pre>";
    //$_SERVER
    //$_GET

    echo $_POST['firstname'].' '.$_POST['lastname'].' <br>';
    echo "{$_POST['firstname']} {$_POST['lastname']}";

    $db = mysqli_connect('localhost', 'root', '', '5122018_39');
    mysqli_set_charset($db, 'utf8');
    $sql = "INSERT INTO users (id, firstname, lastname, age) VALUE 
                (NULL, '{$_POST['firstname']}', '{$_POST['lastname']}', {$_POST['age']})";
    $result = mysqli_query($db, $sql);

    if( $result ){
        echo "Ok";
    }else{
        echo "Error";
    }
