let button = document.querySelector('button');
let resultEl = document.querySelector('.result');

button.addEventListener('click', function(){
    loadUsers();
});

function loadUsers(){
    let ajax = new XMLHttpRequest();
    ajax.open('GET', '/admin/handler.php');
    ajax.send();

    ajax.addEventListener('load', function(){
        resultEl.innerHTML = '';
        // resultEl.innerHTML = ajax.responseText;
        let data = JSON.parse(ajax.responseText);
        console.log(data);
        
        let sum = 0;
        data.users.forEach(function(userItem){
            let div = document.createElement('div');
            div.classList.add('user-item');
            div.innerHTML = `
                <div class='user-item-id'>${userItem.id}</div>
                <div class='user-item-firstname'>${userItem.firstname}</div>
                <div class='user-item-lastname'>${userItem.lastname}</div>
                <div class='user-item-age'>${userItem.age}</div>
            `;

            sum += parseInt(userItem.age);
            
            resultEl.appendChild(div);
        });

        let averageDiv = document.createElement('div');
        averageDiv.classList.add('average');
        averageDiv.innerHTML = sum / data.users.length;

        resultEl.appendChild(averageDiv);

    });
}

setInterval(function(){
    loadUsers();
}, 5000);