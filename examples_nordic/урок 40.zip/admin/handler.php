<?php 
    $response = [
        'users'=>[]
    ];

    $db = mysqli_connect('localhost', 'root', '', '5122018_39');
    mysqli_set_charset($db, 'utf8');

    $sql = "SELECT * FROM users";
    $result = mysqli_query($db, $sql);

    while( $row = mysqli_fetch_assoc($result) ){
        $response['users'][] = $row;
        // echo "
        //     <div class='user-item'>
        //         <span>{$row['id']}</span> <span>{$row['firstname']}</span>
        //     </div>
        // ";
        // echo "<pre>";
        // print_r( $row );
        // echo "</pre>";
    }

    echo json_encode($response);