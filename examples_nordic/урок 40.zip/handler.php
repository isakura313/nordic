<?php
    
    $db = mysqli_connect('localhost', 'root', '', '5122018_38');
    mysqli_set_charset($db, 'utf8');

    $sql = "INSERT INTO words (id, word) VALUE (NULL, '{$_GET['word']}')";
    $result = mysqli_query($db, $sql);

    if( $result ){
        echo "<h1>Вы отправили нам: {$_GET['word']}</h1>";
    }else{
        echo "<h1>Произошла ошибка</h1>";
    }

    sleep(5);

    